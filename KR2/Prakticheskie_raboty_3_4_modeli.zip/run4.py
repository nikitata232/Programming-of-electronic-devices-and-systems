from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
from bisect import bisect_right
import json
import os

from common import ROOT, call, byte_dump, finished, firmware, ucsim, vcd_bits

# Direction, mode, speed in bit/s, buffer address, bytes, oscillator, SMOD, TH1.
VARIANTS = [
    ('T', 0, 1_000_000, 0x50, 10, 12_000_000, 0, 0),
    ('T', 1, 19_200, 0x30, 6, 11_059_200, 1, 0xFD),
    ('R', 2, 375_000, 0x40, 15, 12_000_000, 1, 0),
    ('T', 3, 2_400, 0x50, 8, 11_059_200, 0, 0xF4),
    ('R', 0, 1_000_000, 0x40, 20, 12_000_000, 0, 0),
    ('R', 1, 4_800, 0x60, 10, 11_059_200, 0, 0xFA),
    ('T', 2, 187_500, 0x30, 20, 12_000_000, 0, 0),
    ('T', 3, 62_200, 0x40, 15, 11_942_400, 1, 0xFF),
    ('R', 1, 9_600, 0x30, 20, 11_059_200, 0, 0xFD),
    ('T', 1, 1_200, 0x50, 10, 11_059_200, 0, 0xE8),
]


def scenario(item):
    number, (direction, mode, speed, start, count, freq, smod, reload) = item
    folder = ROOT / 'runs4' / f'v{number:02}'
    pattern = bytes(0x41+i for i in range(count))
    params = dict(PCON_VAL=smod*0x80, RELOAD=reload, BASE_ADDR=start, COUNT=count,
                  USE_T1=int(mode in (1,3)))
    if mode == 0:
        computed = Fraction(freq, 12)
    elif mode == 2:
        computed = Fraction(freq*2**smod, 64)
    else:
        computed = Fraction(freq*2**smod, 384*(256-reload))
    assert computed == speed
    tx_dir = folder/'tx'
    tx = firmware(tx_dir, 'tx', dict(params, SCON_TX=mode*64))
    bytes_hex = ' '.join(f'0x{v:02x}' for v in pattern)
    tx_out = ucsim(tx_dir, 'tx', freq, [
        f'set memory iram 0x{start:02x} {bytes_hex}',
        'set hw vcd output "registers.vcd"', 'set hw vcd add bits 0x90',
        'set hw vcd add bits 0x9b', 'set hw vcd add bits 0x99',
        'set hw vcd start', f'run 0 0x{tx["done"]:04x}', 'state', 'set hw vcd stop',
    ], 'out=sent.bin')
    tx_ticks = finished(tx_out, tx)
    sent = (tx_dir/'sent.bin').read_bytes()
    assert sent == pattern, (number, sent, pattern)
    traced = vcd_bits(tx_dir/'registers.vcd')
    tx_times = [t for t, _ in traced['bits_0x90.0'][1:]]
    assert len(tx_times) == count
    tb8 = traced['bits_0x9b.0']
    parity = [tb8[bisect_right(tb8, (t,1))-1][1] for t in tx_times]
    assert parity == [v.bit_count()%2 for v in sent]
    phy = folder/'phy'
    phy.mkdir(exist_ok=True)
    wire_in = [v+(p<<8) for v,p in zip(sent,parity)] if mode >= 2 else sent
    (phy/'frame_source.hex').write_text(''.join(f'{v:03x}\n' for v in wire_in))
    period = round(Fraction(10**12, speed))
    run_log = call(['vvp', str(ROOT/'runs4'/'uart_wire.vvp'),
                    f'+MODE={mode}', f'+COUNT={count}', f'+BIT_PS={period}'], phy)
    (phy/'icarus.txt').write_text(run_log)
    decoded = [line.split() for line in (phy/'decoded.txt').read_text().splitlines()]
    received = bytes(int(row[0],16) for row in decoded)
    assert received == sent and len(decoded) == count
    assert all(stop == '1' and bad == '0' for _,_,stop,bad in decoded)
    assert [row[1] for row in decoded] == ([str(p) for p in parity] if mode >=2 else ['-']*count)

    rx_dir = folder/'rx'
    rx = firmware(rx_dir, 'rx', dict(params, SCON_RX=mode*64+0x10))
    (rx_dir/'input.bin').write_bytes(received)
    end = start+count-1
    rx_out = ucsim(rx_dir, 'rx', freq, [
        f'fill iram 0x{start:02x} 0x{end:02x} 0x00',
        'set memory uart_0_cfg 0x01 1',
        'set hw vcd output "registers.vcd"', 'set hw vcd add bits 0x98',
        'set hw vcd start', f'run 0 0x{rx["done"]:04x}', 'state',
        f'dump /h iram 0x{start:02x} 0x{end:02x}', 'set hw vcd stop',
    ], 'in=input.bin')
    rx_ticks = finished(rx_out, rx)
    ram = byte_dump(rx_out[rx_out.index('Simulation started, PC='):], start, count, 2)
    assert ram == pattern
    rx_events = vcd_bits(rx_dir/'registers.vcd')['bits_0x98.0']
    assert sum(v for _,v in rx_events) == count
    print(f'Variant {number}: {direction} mode {mode}, {speed} bit/s, {count} bytes OK', flush=True)
    return dict(variant=number, direction=direction, mode=mode, speed=speed,
                start=start, end=end, count=count, oscillator=freq, smod=smod,
                reload=reload if mode in (1,3) else None, period_ps=period,
                tx_ticks=tx_ticks, rx_ticks=rx_ticks,
                data_hex=sent.hex(' ').upper(), payload=sent.decode('ascii'))


if __name__ == '__main__':
    compiler = ['iverilog']
    if base := os.environ.get('LAB34_IVERILOG_BASE'):
        compiler.extend(['-B', base])
    call([*compiler, '-g2012', '-s', 'uart_wire', '-o',
          str(ROOT/'runs4'/'uart_wire.vvp'), str(ROOT/'uart_wire.v')], ROOT)
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(scenario, enumerate(VARIANTS,1)))
    (ROOT/'runs4'/'results.json').write_text(json.dumps(results,indent=2)+'\n')
