from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction
import csv
import json

from common import ROOT, byte_dump, finished, firmware, ucsim, vcd_bits

VARIANTS = [
    ('P1.3', 2, 1, 3), ('P1.7', 3, 2, 5), ('P2.5', 1, .5, 2),
    ('P2.1', .5, 1, 1), ('P3.5', 4, 3, 8), ('P1.6', 6, 4, 10),
    ('P3.2', .7, .3, 2), ('P1.4', 5, 4, 1), ('P2.6', 6, 5, 5),
    ('P3.3', 7, 6, 15),
]


def scenario(item):
    number, (port, on, off, minutes) = item
    bit = 0x80 + int(port[1]) * 16 + int(port[3])
    total = minutes * 60 * 20
    folder = ROOT / 'runs3' / f'v{number:02}'
    labels = firmware(folder, 'timer', dict(
        LED_BIT=bit, ON_TICKS=round(on*20), OFF_TICKS=round(off*20),
        TOTAL_LO=total & 255, TOTAL_HI=total >> 8,
    ))
    output = ucsim(folder, 'timer', 12_000_000, [
        'set hw vcd output "port.vcd"', f'set hw vcd add bits 0x{bit:02x}',
        'set hw vcd start', f'run 0 0x{labels["done"]:04x}', 'state',
        f'dump /h sfr 0x{bit&248:02x} 0x{bit&248:02x}', 'set hw vcd stop',
    ], timeout=360)
    end = finished(output, labels)/12_000_000
    assert byte_dump(output, bit & 248, 1, 2)[0] & (1 << (bit % 8))
    assert '$timescale 1ps $end' in (folder / 'port.vcd').read_text()
    raw = next(iter(vcd_bits(folder / 'port.vcd').values()))
    assert raw[:1] == [(0, 1)] and raw[1][1] == 0 and raw[-1][1] == 1
    origin = raw[1][0]
    actual = [((time-origin)/1e12, state) for time, state in raw[1:]]
    expected = [(Fraction(0), 0)]
    length = minutes * 60
    t, state = Fraction(0), 0
    while t < length:
        t += Fraction(str(on if state == 0 else off))
        if t < length:
            state ^= 1
            expected.append((t, state))
        elif state == 0:
            expected.append((Fraction(length), 1))
    assert len(expected) == len(actual), (port, len(expected), len(actual))
    errors = [abs(float(ideal) - time) for (ideal, s), (time, a) in zip(expected, actual)
              if s == a]
    assert len(errors) == len(expected) and max(errors) < 25e-6, (number, max(errors))
    elapsed = end-origin/1e12
    assert abs(elapsed-length) < 25e-6
    with (folder / 'edges.csv').open('w', newline='') as f:
        out = csv.writer(f)
        out.writerow(['seconds_after_first_on', 'port_level', 'led_state'])
        out.writerows((f'{t:.9f}', s, 1-s) for t, s in actual)
    print(f'Variant {number}: {len(actual)} transitions over {elapsed:.9f} s', flush=True)
    return dict(variant=number, port=port, on=on, off=off, minutes=minutes,
                elapsed=elapsed, delta_us=round(max(errors)*1e6, 3),
                on_first=actual[1][0], off_first=actual[2][0]-actual[1][0],
                starts=sum(s == 0 for _, s in actual))


if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=8) as pool:
        results=list(pool.map(scenario, enumerate(VARIANTS, 1)))
    (ROOT / 'runs3' / 'results.json').write_text(json.dumps(results, indent=2)+'\n')
