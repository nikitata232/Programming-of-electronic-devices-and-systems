`timescale 1ps/1ps
module uart_wire;
    reg data_line = 1, shift_clock = 1, frame_start = 0;
    reg [8:0] source_words [0:31];
    reg [8:0] word_rx = 0;
    integer mode, count, send_index, bit_index, sample_index;
    integer async_bit, read_count = 0, result;
    reg [8:0] captured;
    time period, half_period;
    reg bad_parity;

    initial begin
        if (!$value$plusargs("MODE=%d", mode)) $fatal(1, "MODE required");
        if (!$value$plusargs("COUNT=%d", count)) $fatal(1, "COUNT required");
        if (!$value$plusargs("BIT_PS=%d", period)) $fatal(1, "BIT_PS required");
        half_period = period / 2;
        $readmemh("frame_source.hex", source_words, 0, count-1);
        $dumpfile("wire.vcd");
        $dumpvars(0, data_line, shift_clock, frame_start);
        result = $fopen("decoded.txt", "w");
        sample_index = 0;
        #(2*period);
        for (send_index=0; send_index<count; send_index=send_index+1) begin
            frame_start = 1;
            if (mode == 0) begin
                for (bit_index=0; bit_index<8; bit_index=bit_index+1) begin
                    shift_clock = 0;
                    data_line = source_words[send_index][bit_index];
                    #(half_period) shift_clock = 1;
                    #(period-half_period);
                end
            end else begin
                data_line = 0;
                #period;
                for (bit_index=0; bit_index<8; bit_index=bit_index+1) begin
                    data_line = source_words[send_index][bit_index];
                    #period;
                end
                if (mode >= 2) begin
                    data_line = source_words[send_index][8];
                    #period;
                end
                data_line = 1;
                #period;
            end
            frame_start = 0;
            data_line = 1;
            #(2*period);
        end
        if (read_count != count) $fatal(1, "missing frames");
        $fclose(result);
        $finish;
    end

    // In mode 0 the clock is supplied by the controller owning the bus.
    always @(posedge shift_clock) if (mode == 0 && frame_start) begin
        word_rx[sample_index] = data_line;
        sample_index = sample_index + 1;
        if (sample_index == 8) begin
            $fdisplay(result, "%02h - 1 0", word_rx[7:0]);
            sample_index = 0;
            read_count = read_count + 1;
        end
    end

    // The asynchronous receiver samples the centers of the bit cells.
    always @(negedge data_line) if (mode != 0) begin
        #(half_period);
        if (data_line !== 0) $fatal(1, "invalid start");
        captured = 0;
        for (async_bit=0; async_bit<8; async_bit=async_bit+1) begin
            #period captured[async_bit] = data_line;
        end
        if (mode >= 2) begin
            #period captured[8] = data_line;
        end
        #period;
        if (data_line !== 1) $fatal(1, "invalid stop");
        bad_parity = mode >= 2 && (^captured);
        if (mode >= 2)
            $fdisplay(result, "%02h %0d %0d %0d", captured[7:0], captured[8], data_line, bad_parity);
        else
            $fdisplay(result, "%02h - %0d %0d", captured[7:0], data_line, bad_parity);
        read_count = read_count + 1;
    end
endmodule
