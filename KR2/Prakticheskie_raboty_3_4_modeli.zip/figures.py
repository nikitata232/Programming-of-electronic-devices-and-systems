import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle
from matplotlib.ticker import MultipleLocator

from common import ROOT

F = ROOT/'figs'
F.mkdir(exist_ok=True)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9,'axes.linewidth':.75})


def save(fig, name):
    fig.savefig(F/(name+'.png'), dpi=265, facecolor='white')
    plt.close(fig)


def drawing(width, height):
    fig,ax=plt.subplots(figsize=(9, 9*height/width))
    ax.set_position((.012,.02,.976,.96))
    ax.set(xlim=(0,width),ylim=(0,height))
    ax.axis('off')
    return fig, ax


def wire(ax, points, width=1):
    ax.plot(*zip(*points),c='black',lw=width,solid_capstyle='butt')


def box(ax,x,y,w,h):
    ax.add_patch(Rectangle((x,y),w,h,fc='white',ec='black',lw=1))


def label(ax,x,y,s,ha='center',size=9,bold=False):
    ax.text(x,y,s,ha=ha,va='center',fontsize=size,fontweight='bold' if bold else 'normal')


def dot(ax,x,y):
    ax.add_patch(Circle((x,y),.58,fc='black',ec='none'))


def ground(ax,x,y):
    wire(ax,[(x,y),(x,y-2)])
    for dy,dx in ((2,2.2),(3,1.45),(4,.65)):
        wire(ax,[(x-dx,y-dy),(x+dx,y-dy)],.8)


def meter(ax,x,y,id,kind):
    ax.add_patch(Circle((x,y),4.3,ec='black',fc='white',lw=1))
    label(ax,x,y,kind,size=10,bold=True)
    label(ax,x,y+8,id,size=8)
    label(ax,x-5.4,y+3,'+',size=7)
    label(ax,x+5.4,y+3,'−',size=7)


def led_scheme():
    fig,ax=drawing(154,55)
    box(ax,112,10,36,35)
    label(ax,130,40,'DD1  AT89S51',bold=True)
    for y, name in [(29,'P1.3 (7)'),(21,'VCC, /EA'),(15,'GND')]:
        label(ax,114,y,name,'left',8)
    wire(ax,[(9,29),(19,29)])
    label(ax,9,33,'+5 В',size=8)
    box(ax,19,27.3,12,3.4)
    label(ax,25,35,'R1  2,2 кОм',size=8)
    wire(ax,[(31,29),(46.7,29)])
    meter(ax,51,29,'XMM1','A')
    wire(ax,[(55.3,29),(72,29)])
    dot(ax,65,29)
    ax.add_patch(Polygon([(72,26.6),(72,31.4),(77,29)],closed=True,ec='black',fc='white',lw=1))
    wire(ax,[(77,26.4),(77,31.6)])
    wire(ax,[(77,29),(112,29)])
    dot(ax,86,29)
    label(ax,74.5,21.5,'HL1',size=8)
    for dx in (0,2.2):
        ax.annotate('',xy=(76+dx,35.8),xytext=(72.6+dx,32.9),
                    arrowprops=dict(arrowstyle='->',color='black',lw=.65))
    wire(ax,[(65,29),(65,42),(71.2,42)])
    meter(ax,75.5,42,'XMM2','V')
    wire(ax,[(79.8,42),(86,42),(86,29)])
    wire(ax,[(103,21),(112,21)])
    label(ax,102,21,'+5 В','right',8)
    wire(ax,[(107,15),(112,15)])
    ground(ax,107,15)
    label(ax,129,5,'G1  12 МГц на XTAL1',size=8)
    save(fig,'led_scheme')


def axes_style(ax):
    ax.grid(True,lw=.48,color='.65',linestyle=':')
    ax.tick_params(labelsize=8,length=3)
    ax.set_axisbelow(True)


def timer_graphs():
    run=ROOT/'runs3'/'v01'
    with (run/'edges.csv').open() as f:
        edges=[(float(r['seconds_after_first_on']),int(r['port_level'])) for r in csv.DictReader(f)]
    with (run/'led_spice.txt').open() as f:
        next(f)
        data=[[float(v) for v in line.split()] for line in f if line.strip()]
    fig, axs=plt.subplots(3,1,figsize=(8.9,4.6),sharex=True)
    fig.subplots_adjust(left=.15,right=.98,top=.97,bottom=.12,hspace=.16)
    for i, (ax, name, limits, ticks) in enumerate(zip(axs,['P1.3, В','I HL1, мА','U HL1, В'],
          [(-.5,5.5),(-.12,1.52),(-.17,2.35)],[[0,5],[0,1.29],[0,1.97]])):
        if i==0:
            ax.step([t for t,_ in edges],[5*v for _,v in edges],where='post',c='black',lw=1.25)
        else:
            col=2 if i==1 else 1
            ax.plot([r[0] for r in data],[r[col]*(1000 if i==1 else 1) for r in data],c='black',lw=1.25)
        ax.set(xlim=(0,7),ylim=limits,yticks=ticks)
        ax.xaxis.set_major_locator(MultipleLocator(1))
        ax.set_ylabel(name,fontsize=9)
        axes_style(ax)
    axs[-1].set_xlabel('Время от включения, с')
    save(fig,'led_graph')
    folder=ROOT/'runs3'/'v09'
    with (folder/'edges.csv').open() as f:
        edges=[(float(r['seconds_after_first_on']),int(r['led_state'])) for r in csv.DictReader(f)]
    edges.append((302,0))
    fig,ax=plt.subplots(figsize=(8.9,1.9))
    fig.subplots_adjust(left=.15,right=.98,top=.93,bottom=.28)
    ax.step([t for t,_ in edges],[v for _,v in edges],where='post',c='black',lw=1.25)
    ax.axvline(300,c='black',lw=.75,ls='--')
    ax.set(xlim=(285,302),ylim=(-.18,1.18),yticks=[0,1],ylabel='Состояние HL1',xlabel='Время от включения, с')
    ax.xaxis.set_major_locator(MultipleLocator(2))
    axes_style(ax)
    save(fig,'led_cutoff')


def uart_scheme():
    fig,ax=drawing(157,96)
    configurations=[
      (76,'а) Синхронная передача, вариант 1','DD1  8051, передатчик','Приёмник / анализатор',
       ('P3.0 (10)','DATA →','DATA IN'),('P3.1 (11)','CLK →','CLK IN')),
      (44,'б) Синхронный приём, вариант 5','DD1  8051, приёмник','DD2  ведомый источник',
       ('P3.0 (10)','← DATA','DATA OUT'),('P3.1 (11)','CLK →','CLK IN')),
      (12,'в) Асинхронный обмен, варианты 2–4 и 6–10','DD1  8051, передатчик','DD2  8051, приёмник',
       ('P3.1 (11)','TXD → RXD','P3.0 (10)'),None),
    ]
    for y, title, left, right, data, clock in configurations:
        label(ax,4,y+16,title,'left',9,bold=True)
        box(ax,4,y-8,42,20); box(ax,108,y-8,45,20)
        label(ax,25,y+8,left,size=8.2,bold=True)
        label(ax,130.5,y+8,right,size=8.2,bold=True)
        for yy,item in [(y+2,data),(y-2,clock),(y-6,('GND','Общий провод','GND'))]:
            if not item:
                continue
            a,net,b=item
            label(ax,44,yy,a,'right',7.3)
            label(ax,110,yy,b,'left',7.3)
            wire(ax,[(46,yy),(108,yy)])
            label(ax,77,yy+1.5,net,size=7.0)
        dot(ax,92,y+2)
        wire(ax,[(92,y+2),(92,y+9),(99,y+9)])
        label(ax,99,y+10.8,'XSC1 A+',size=7.1)
    save(fig,'uart_scheme')


def vcd_wires(path):
    ids, events, t = {},{},0
    for line in path.read_text().splitlines():
        if line.startswith('$var reg 1 '):
            _,_,_,c,name,*_=line.split()
            ids[c]=name
            events[name]=[]
        elif line.startswith('#'):
            t=int(line[1:])
        elif line and line[0] in '01' and line[1:] in ids:
            events[ids[line[1:]]].append((t,int(line[0])))
    return events


def frame(ax,v,caption,frame_number=0):
    mode=v['mode']
    folder=ROOT/'runs4'/f'v{v["variant"]:02}'/'phy'
    ev=vcd_wires(folder/'wire.vcd')
    period=v['period_ps']
    length=[8,10,11,11][mode]
    origin=[t for t,b in ev['frame_start'] if b][frame_number]
    data=bytes.fromhex(v['data_hex'])[frame_number]
    cell=[f'D{i}' for i in range(8)]
    if mode:
        cell=['Старт',*cell]+(['P'] if mode>=2 else [])+['Стоп']
    for i, name in enumerate(cell):
        ax.text((i+.5)*period/1e6,1.41,name,ha='center',va='center',fontsize=8)
    for i in range(length+1):
        ax.axvline(i*period/1e6,c='.65',lw=.55,ls=':',zorder=0)
    def steps(name, offset):
        trace=ev[name]
        begin=[val for t,val in trace if t<=origin][-1]
        part=[(0,begin)]+[(t-origin,val) for t,val in trace if origin<t<origin+period*length]
        part.append((period*length,part[-1][1]))
        ax.step([t/1e6 for t,_ in part],[offset+val for _,val in part],where='post',c='black',lw=1.35)
    steps('data_line',0)
    if mode==0:
        steps('shift_clock',-1.65)
    ax.set(xlim=(0,length*period/1e6),ylim=((-1.85 if mode==0 else -.21),1.65),
           yticks=([-1.65,-.65,0,1] if mode==0 else [0,1]),xlabel='Время от начала кадра, мкс')
    if mode==0:
        ax.set_yticklabels(['CLK 0','CLK 1','DATA 0','DATA 1'])
    else:
        ax.set_ylabel('TXD / RXD')
    ax.tick_params(labelsize=8)
    ax.set_title(f'{caption} · {data:02X}h',fontsize=9.5,pad=6)


def uart_graphs():
    r=json.loads((ROOT/'runs4'/'results.json').read_text())
    for number, cases in enumerate([[(1,'Режим 0 · 1000 кбит/с',0),(2,'Режим 1 · 19,2 кбит/с',0)],
                                  [(3,'Режим 2 · 375 кбит/с',2),(4,'Режим 3 · 2,4 кбит/с',0)]],1):
        fig,axs=plt.subplots(2,1,figsize=(8.9,4.6))
        fig.subplots_adjust(left=.13,right=.98,top=.93,bottom=.12,hspace=.73)
        for ax,(case,cap,idx) in zip(axs,cases):
            frame(ax,r[case-1],cap,idx)
        save(fig,f'uart_graph{number}')


if __name__ == '__main__':
    led_scheme()
    timer_graphs()
    uart_scheme()
    uart_graphs()
