.module uart_rx
.include "params.inc"
.area PROGRAM (ABS,CODE)
.org 0x0000
    mov  0x98,#SCON_RX    ; SCON: режим порта и REN = 1
    mov  0x87,#PCON_VAL   ; PCON: SMOD
.if USE_T1
    mov  0x89,#0x20       ; T1: автоперезагрузка
    mov  0x8D,#RELOAD    ; TH1
    mov  0x8B,#RELOAD    ; TL1
    setb 0x8E             ; TR1
.endif
    mov  r0,#BASE_ADDR   ; начало приёмного буфера
    mov  r7,#COUNT
wait_ri:
    jnb  0x98,wait_ri     ; ждать RI
    mov  a,0x99          ; прочитать принятый байт из SBUF
    mov  @r0,a           ; сохранить его во внутреннем ОЗУ
    clr  0x98             ; освободить приёмник
    inc  r0
    djnz r7,wait_ri
    clr  0x9C             ; REN = 0 после приёма N байт
done:
    sjmp done
