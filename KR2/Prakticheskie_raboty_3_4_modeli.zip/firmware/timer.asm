.module timed_led
.include "params.inc"
.area PROGRAM (ABS,CODE)
.org 0x0000
    ljmp main
.org 0x000B
    ljmp timer0_isr       ; вектор переполнения T0
.org 0x0030
main:
    mov  0x89,#0x02       ; TMOD: T0, режим 2, таймер без GATE
    mov  0x8C,#0x06       ; TH0: 256 − 6 = 250 тактов
    mov  0x8A,#0x06       ; TL0: такое же первое переполнение
    mov  r0,#200          ; 200 × 250 мкс = 50 мс
    mov  r1,#ON_TICKS     ; остаток текущей фазы
    mov  r2,#TOTAL_LO     ; остаток работы: младший байт
    mov  r3,#TOTAL_HI     ; остаток работы: старший байт
    mov  0xA8,#0x82       ; EA и ET0
    clr  LED_BIT         ; активный 0 включает светодиод
    setb 0x8C             ; TR0 = 1
idle:
    orl  0x87,#0x01       ; IDL: ядро ждёт прерывания, T0 считает
    sjmp idle

timer0_isr:
    djnz r0,irq_exit      ; каждые 50 мс выполнить полный шаг
    mov  r0,#200
    mov  a,r2
    jnz  dec_low
    dec  r3               ; заём из старшего байта
dec_low:
    dec  r2
    mov  a,r2
    orl  a,r3
    jz   end_run          ; общий лимит важнее смены фазы
    djnz r1,irq_exit
    cpl  LED_BIT
    jb   LED_BIT,off_time
    mov  r1,#ON_TICKS
    reti
off_time:
    mov  r1,#OFF_TICKS
irq_exit:
    reti                 ; TF0 очищается при входе в обработчик
end_run:
    clr  0x8C             ; остановить T0
    setb LED_BIT         ; погасить светодиод
done:
    reti
