.module uart_tx
.include "params.inc"
.area PROGRAM (ABS,CODE)
.org 0x0000
    mov  0x98,#SCON_TX    ; SCON: режим порта, REN = 0
    mov  0x87,#PCON_VAL   ; PCON: SMOD, если требуется
.if USE_T1
    mov  0x89,#0x20       ; T1: режим 2, автоперезагрузка
    mov  0x8D,#RELOAD    ; TH1
    mov  0x8B,#RELOAD    ; TL1
    setb 0x8E             ; TR1; ET1 остаётся сброшенным
.endif
    mov  r0,#BASE_ADDR   ; начало буфера во внутреннем ОЗУ
    mov  r7,#COUNT
next_byte:
    clr  0x99             ; TI = 0
    mov  a,@r0            ; байт из резидентного ОЗУ
    mov  c,0xD0          ; PSW.P: 1 при нечётном числе единиц
    mov  0x9B,c          ; TB8: дополнение до чётности, режимы 2/3
    cpl  0x90             ; контрольная метка P1.0
    mov  0x99,a          ; SBUF: начать передачу
wait_ti:
    jnb  0x99,wait_ti     ; дождаться TI
    inc  r0
    djnz r7,next_byte
done:
    sjmp done
