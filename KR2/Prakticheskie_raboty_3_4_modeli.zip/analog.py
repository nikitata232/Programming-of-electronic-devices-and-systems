import csv
import json

from common import ROOT, call

runs = ROOT/'runs3'
results = json.loads((runs/'results.json').read_text())
template = (ROOT/'led_measure.cir').read_text()


def run(case):
    folder = runs/f'v{case["variant"]:02}'
    with (folder/'edges.csv').open() as f:
        edges = [(float(row['seconds_after_first_on']), int(row['port_level']))
                 for row in csv.DictReader(f)]
    stop = case['elapsed'] + .1
    points = [(0, 0)]
    for t, s in edges[1:]:
        points.extend([(t-1e-6, points[-1][1]), (t, 5*s)])
    (folder/'led.cir').write_text(template+'VPORT out 0 PWL(\n'+
        ''.join(f'+ {t:.9f} {v}\n' for t,v in points)+f'''+ {stop:.9f} 5)
.control
set wr_singlescale
set wr_vecnames
tran 0.05 {stop:.9f}
wrdata led_spice.txt v(anode,cathode) i(VAMM) v(cathode)
quit
.endc
.end
''')
    log = call(['ngspice', '-n', '-b', 'led.cir'], folder)
    (folder/'spice.log').write_text(log)
    assert 'Error' not in log and 'No. of Data Rows' in log
    with (folder/'led_spice.txt').open() as f:
        next(f)
        rows = [[float(v) for v in line.split()] for line in f if line.strip()]
    def near(t):
        return min(rows, key=lambda row: abs(row[0]-t))[1:]
    on = near(case['on']/2)
    off = near(case['on']+case['off']/2)
    final = near(stop)
    assert 0.1 < on[1]*1000 < 1.6 and 1.5 < on[0] < 2.4
    assert all(abs(x[1]) < 1e-9 for x in (off,final))
    assert abs(5-(on[1]*2200+on[0]+on[2]))<1e-6
    return {'on':on, 'off':off, 'final':final}


if __name__ == '__main__':
    analog = [run(v) for v in results]
    (runs/'analog.json').write_text(json.dumps(analog,indent=2)+'\n')
    print(analog[0], 'for all', len(analog), 'variants')
