"""Build SDCC assembly and collect reproducible uCsim console output."""
import re
import shutil
import subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def call(argv, folder, commands=None, timeout=60):
    result = subprocess.run(argv, cwd=folder, input=commands, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=timeout)
    if result.returncode:
        raise RuntimeError(f'{argv}: {result.stdout}')
    return result.stdout


def firmware(folder, name, params):
    folder.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(ROOT / 'firmware' / f'{name}.asm', folder / f'{name}.asm')
    (folder / 'params.inc').write_text(''.join(f'{key} = 0x{value:X}\n'
                                               for key, value in params.items()))
    call(['sdas8051', '-los', f'{name}.asm'], folder)
    call(['sdld', '-i', f'{name}.rel'], folder)
    labels = {label: int(addr, 16) for addr, label in re.findall(
        r'^\s*([\dA-F]{6})\s+\d+\s+(\w+):', (folder / f'{name}.lst').read_text(), re.M)}
    return labels


def ucsim(folder, name, freq, commands, serial=None, timeout=60, cpu='C51'):
    argv = ['s51', '-q', '-R', '1', '-t', cpu, '-X', str(freq), '-c', '-']
    if serial:
        argv.extend(['-S', serial])
    output = call([*argv, name + '.ihx'], folder, '\n'.join(commands + ['quit']) + '\n', timeout)
    output = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', output)
    (folder / 'ucsim.txt').write_text(output)
    return output


def finished(output, labels):
    assert f'Stop at 0x{labels["done"]:06x}:' in output, output
    return int(re.search(r'Total time since last reset=.*?\((\d+) clks\)', output)[1])


def byte_dump(output, start, size, digits):
    values = {}
    for addr, row in re.findall(r'^0x([\da-f]{'+str(digits)+r'})\s+((?:[\da-f]{2} )+)', output, re.M):
        values.update((int(addr, 16)+offset, int(value, 16))
                      for offset, value in enumerate(row.split()))
    return bytes(values[x] for x in range(start, start + size))


def vcd_bits(path):
    definitions, events, previous = {}, {}, {}
    time = 0
    for line in path.read_text().splitlines():
        if line.startswith('$var wire 1 '):
            _, _, _, ident, name, *_ = line.split()
            definitions[ident] = name
            events[name] = []
        elif line.startswith('#'):
            time = int(line[1:])
        elif line and line[0] in '01' and line[1:] in definitions:
            ident, value = line[1:], int(line[0])
            if previous.get(ident) != value:
                events[definitions[ident]].append((time, value))
                previous[ident] = value
    return events
