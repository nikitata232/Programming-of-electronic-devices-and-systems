; Проверка контрольной суммы внешнего ПЗУ 8051.
.module rom_test
.include "params.inc"
.area PROGRAM (ABS,CODE)
.org 0x0000
    setb 0x90              ; P1.0 = 1, светодиод HL1 погашен
    mov  0x30,#0           ; состояние проверки
    mov  dptr,#START_ADDR  ; начало проверяемой области
    mov  r6,#TAIL          ; K mod 256, 0 означает полный блок
    mov  r7,#BLOCKS        ; число блоков, включая неполный
    mov  r2,#0             ; младший байт суммы
    mov  r3,#0             ; средний байт суммы
    mov  r4,#0             ; старший байт суммы
scan:
    movx a,@dptr           ; прочитать внешнее ПЗУ через /RD
    add  a,r2             ; сложить байт с младшей частью суммы
    mov  r2,a
    clr  a
    addc a,r3             ; прибавить перенос к среднему байту
    mov  r3,a
    clr  a
    addc a,r4             ; прибавить перенос к старшему байту
    mov  r4,a
    inc  dptr
    djnz r6,scan          ; дочитать текущий блок
    djnz r7,scan          ; дочитать оставшиеся блоки
    mov  dptr,#reference  ; эталон хранится во внутреннем ПЗУ
    clr  a
    movc a,@a+dptr        ; прочитать младший байт эталона
    xrl  a,r2
    jnz  fail
    mov  a,#1
    movc a,@a+dptr        ; прочитать средний байт эталона
    xrl  a,r3
    jnz  fail
    mov  a,#2
    movc a,@a+dptr        ; прочитать старший байт эталона
    xrl  a,r4
    jnz  fail
    mov  0x30,#1          ; контрольная сумма совпала
    sjmp halt
fail:
    clr  0x90             ; P1.0 = 0, светодиод HL1 включён
    mov  0x30,#2          ; контрольная сумма не совпала
halt:
    sjmp halt
reference:
    .db SUM_LO,SUM_MID,SUM_HI
