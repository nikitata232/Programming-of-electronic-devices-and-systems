"""Render monochrome bus schematics and selected oscilloscope captures."""
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle, Polygon, Rectangle
from matplotlib.ticker import MultipleLocator

HERE = Path(__file__).resolve().parent
OUT = HERE / 'figures'
OUT.mkdir(exist_ok=True)
plt.rcParams.update({'font.family': 'DejaVu Sans', 'svg.fonttype': 'path'})


def save(fig, name):
    for ext in ('png', 'svg'):
        fig.savefig(OUT / f'{name}.{ext}', dpi=260, facecolor='white')
    plt.close(fig)


def scheme(rom):
    fig, ax = plt.subplots(figsize=(9, 4.43))
    ax.set_position((0.005, 0.01, 0.99, 0.98))
    ax.set(xlim=(0, 162), ylim=(1, 87))
    ax.axis('off')

    def wire(points, width=1):
        ax.plot(*zip(*points), color='black', lw=width, solid_capstyle='butt')

    def label(x, y, s, ha='left', size=8, bold=False):
        ax.text(x, y, s, ha=ha, va='center', fontsize=size, color='black',
                fontweight='bold' if bold else 'normal')

    def box(x, y, w, h):
        ax.add_patch(Rectangle((x, y), w, h, ec='black', fc='white', lw=1.05))

    def dot(x, y):
        ax.add_patch(Circle((x, y), 0.7, fc='black', ec='black', lw=0))

    def ground(x, y):
        wire([(x, y), (x, y - 2)])
        for dy, dx in ((2, 2), (3, 1.3), (4, 0.55)):
            wire([(x-dx, y-dy), (x+dx, y-dy)], .75)

    box(25, 24, 31, 54)
    box(70, 58, 31, 20)
    box(126, 25, 33, 53)
    box(84, 5, 25, 15)
    label(40.5, 73, 'DD1  AT89S51', 'center', 9, True)
    label(85.5, 73, 'DD2  74HCT573', 'center', 9, True)
    label(142.5, 73, 'DD3  EPROM' if rom else 'DD3  SRAM', 'center', 9, True)
    label(96.5, 15, 'DD4', 'center', 8, True)
    label(96.5, 10, 'Дешифратор', 'center', 7)

    for y, text in ((65,'P0[7:0]'),(46,'P2[7:0]'),(39,'P3.7 /RD'),
                    (25.9,'ALE'),(30.5,'/PSEN')):
        label(54.5, y, text, 'right')
    if not rom:
        label(54.5, 33.8, 'P3.6 /WR', 'right')
    for y, text in ((65,'D[7:0]'),(59.8,'LE')):
        label(71.4, y, text, size=7.5)
    label(99.6, 65, 'Q[7:0]', 'right', 7.5)
    for y, text in ((65,'Q[7:0]' if rom else 'DQ[7:0]'),
                    (57,'A[7:0]'),(46,'A[m−1:8]'),(39,'/OE'),(27.5,'/CE')):
        label(127.4, y, text)
    if not rom:
        label(127.4, 33.8, '/WE')
    label(142, 57, '27C64/128/256' if rom else '6116 / 6264', size=7)

    wire([(56,65),(70,65)], 1.65)
    dot(63,65)
    wire([(63,65),(63,81),(114,81),(114,65),(126,65)], 1.65)
    label(89, 84.1, 'AD[7:0] / D[7:0]', 'center', 8)
    wire([(101,65),(108,65),(108,57),(126,57)], 1.65)
    label(116.5, 60.1, 'A[7:0]', 'center', 7.3)
    wire([(56,46),(126,46)], 1.65)
    label(106, 49.0, 'A[15:8]  (P2[7:0])', 'center')
    wire([(56,39),(126,39)])
    if not rom:
        wire([(56,33.8),(126,33.8)])
    wire([(56,25.9),(63,25.9)])
    label(64, 25.9, 'ALE', size=7.5)
    wire([(64,59.8),(70,59.8)])
    label(63.3, 59.8, 'ALE', 'right', 7.5)
    wire([(85,58),(85,54)])
    label(87.0, 55.7, '/OE', size=7)
    ground(85,54)
    wire([(76,10),(84,10)], 1.45)
    label(74.9, 10, 'A[15:m]', 'right', 7.3)
    wire([(109,12),(116,12),(116,27.5),(126,27.5)])
    label(117.5, 19, '/CE', size=7)

    for y, text in ((64,'XTAL1'),(57.5,'RST'),(51.5,'/EA'),(43,'P1.0')):
        label(26.3, y, text, size=7.5)
        wire([(19.5,y),(25,y)])
    label(18.5, 64, 'G1  12 МГц', 'right', 7.2)
    label(18.5, 57.5, 'G2  Сброс', 'right', 7.2)
    label(18.5, 51.5, '+5 В', 'right', 7.2)

    # Active-low indicator, conventional resistor and diode symbols.
    wire([(19.5,43),(17,43),(17,38.8)])
    wire([(14.9,38.8),(19.1,38.8)])
    ax.add_patch(Polygon([(17,39),(14.9,35.1),(19.1,35.1)],
                         closed=True, ec='black', fc='white', lw=1))
    for dx, dy in ((0,0), (1.2,1.5)):
        ax.annotate('', xy=(22.2+dx,38.2+dy), xytext=(19.3+dx,36.2+dy),
                    arrowprops=dict(arrowstyle='->', lw=.6, color='black'))
    wire([(17,35.1),(17,33.1)])
    box(15.5, 27.9, 3, 5.2)
    wire([(17,27.9),(17,24.4)])
    label(14, 37.3, 'HL1', 'right', 7.5)
    label(14, 30.5, 'R1  2,2 кОм', 'right', 7.0)
    label(17, 22, '+5 В', 'center', 7.2)

    box(27, 4, 30, 16)
    label(42, 16.7, 'XSC1', 'center', 8, True)
    for row, channel, signal in [(12,'A','ALE'), (7,'B','/RD' if rom else '/WR')]:
        label(28.4, row, channel + '+', size=7.3)
        label(55.6, row, channel + '−', 'right', 7.3)
        wire([(21,row),(27,row)])
        label(20, row, signal, 'right', 7.3)
        wire([(57,row),(61,row)])
    wire([(61,12),(61,7)])
    dot(61,7)
    ground(61,7)
    save(fig, 'scheme_rom' if rom else 'scheme_ram')


def osc(variant, strobe, name):
    folder = HERE / 'runs' / f'variant_{variant:02}'
    trace = json.loads((folder / 'normal_trace.json').read_text())
    with (folder / 'normal_bus.csv').open(newline='') as file:
        first_event = next(csv.DictReader(file))
    origin = int(first_event['clock_tick']) - 30
    fig, axes = plt.subplots(2, 1, figsize=(8.6, 2.58), sharex=True)
    fig.subplots_adjust(left=.15, right=.98, top=.95, bottom=.18, hspace=.24)
    for ax, (signal, label) in zip(axes, [('ALE','A  ALE'), strobe]):
        levels = [(tick, value) for tick, net, value in trace if net == signal]
        initial = next(value for tick, value in reversed(levels) if tick <= origin)
        changes = [(0, initial)] + [(tick - origin, value) for tick, value in levels
                                    if origin < tick <= origin + 120]
        changes.append((120, changes[-1][1]))
        ax.step([tick/12 for tick, _ in changes], [v*5 for _, v in changes],
                where='post', c='black', lw=1.4)
        ax.set(xlim=(0,10), ylim=(-.55,5.55), yticks=[0,5])
        ax.xaxis.set_major_locator(MultipleLocator(1))
        ax.tick_params(labelsize=9, length=3)
        ax.grid(True, color='black', linestyle=(0,(1,4)), alpha=.48, lw=.55)
        ax.set_ylabel(label + ', В', rotation=0, labelpad=17, fontsize=9, ha='right')
        ax.yaxis.set_label_coords(-.049,.41)
        for spine in ax.spines.values():
            spine.set_linewidth(.65)
    axes[-1].set_xlabel('Время, мкс', fontsize=9, labelpad=3)
    save(fig, name)


if __name__ == '__main__':
    scheme(False)
    scheme(True)
    osc(1, ('WR_N','B  /WR'), 'ale_ram')
    osc(7, ('RD_N','B  /RD'), 'ale_rom')
