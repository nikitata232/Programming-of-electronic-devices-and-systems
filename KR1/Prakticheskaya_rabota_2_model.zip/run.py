#!/usr/bin/env python3
"""Build 8051 firmware, run uCsim and verify it against the digital bus model."""
import csv
import json
import re
import shutil
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / 'runs'
RAM = [(8, 0xAA, 0x0800), (2, 0x55, 0x0100), (8, 0x00, 0x0C00),
       (8, 0xFF, 0x1000), (8, 0x55, 0x1400), (2, 0xAA, 0x0400)]
ROM = [(8, 100, 0x0800), (16, 300, 0x1000), (32, 500, 0x2000),
       (8, 150, 0x0C00), (16, 350, 0x1000), (32, 650, 0x0400)]


def command(argv, folder, commands=None):
    result = subprocess.run(argv, cwd=folder, input=commands, text=True,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            check=True, timeout=30)
    return result.stdout


def make_firmware(folder, kind, params):
    folder.mkdir(parents=True, exist_ok=True)
    (folder / 'params.inc').write_text(
        ''.join(f'{key} = 0x{value:X}\n' for key, value in params.items()))
    shutil.copyfile(HERE / (kind + '.asm'), folder / (kind + '.asm'))
    command(['sdas8051', '-los', kind + '.asm'], folder)
    command(['sdld', '-i', kind + '.rel'], folder)
    listing = (folder / (kind + '.lst')).read_text()
    labels = {label: int(address, 16) for address, label in re.findall(
        r'^\s*([\dA-F]{6})\s+\d+\s+(\w+):', listing, re.M)}
    clocks = {int(address, 16): int(ticks) for address, ticks in re.findall(
        r'^\s*([\dA-F]{6})\s+[^\n]*?\[(\d+)\]', listing, re.M)}
    program = bytearray(4096)
    for line in (folder / (kind + '.ihx')).read_text().splitlines():
        record = bytes.fromhex(line[1:])
        assert sum(record) & 255 == 0
        size, addr, flag = record[0], int.from_bytes(record[1:3], 'big'), record[3]
        if flag == 0:
            program[addr:addr + size] = record[4:4 + size]
        else:
            assert flag == 1
    return program, labels, clocks


def get_dump(output, start, length, width):
    rows = re.findall(r'^0x([a-f0-9]{' + str(width) +
                      r'})\s+((?:[a-f0-9]{2} )+)', output, re.M)
    values = {}
    for addr, row in rows:
        values.update({int(addr, 16) + offset: int(value, 16)
                       for offset, value in enumerate(row.split())})
    return bytes(values[i] for i in range(start, start + length))


def run_ucsim(folder, kind, labels, memory, start, inject, pattern):
    end = len(memory) - 1
    commands = []
    if kind == 'ram':
        commands.append(f'fill xram 0 0x{end:x} 0x{memory[0]:02x}')
        if inject:
            pc = labels['readback']
            commands += [f'run 0 0x{pc:x}',
                         f'set memory xram 0x{start:x} 0x{pattern ^ 1:02x}']
        else:
            pc = 0
    else:
        for offset in range(0, len(memory), 32):
            row = ' '.join(f'0x{b:02x}' for b in memory[offset:offset + 32])
            commands.append(f'set memory xram 0x{offset:x} {row}')
        pc = 0
    commands += [f'run 0x{pc:x} 0x{labels["halt"]:x}', 'state',
                 'dump /h iram 0x30 0x30', 'dump /h sfr 0x90 0x90',
                 'dump /h iram 0x02 0x04', f'dump /h xram 0 0x{end:x}', 'quit']
    output = command(['s51', '-q', '-t', '51', '-X', '12M', '-c', '-',
                      kind + '.ihx'], folder, '\n'.join(commands) + '\n')
    final = output[output.rindex('Simulation started, PC='):]
    assert f'Stop at 0x{labels["halt"]:06x}:' in final, final
    assert 'frequency= 12000000 HZ' in final
    ticks = int(re.search(r'Total time since last reset=.*?\((\d+) clks\)', final)[1])
    dptr = int(re.search(r'DPTR= 0x([a-f0-9]+)', final)[1], 16)
    status = get_dump(final, 0x30, 1, 2)[0]
    port = get_dump(final, 0x90, 1, 2)[0]
    checksum = int.from_bytes(get_dump(final, 2, 3, 2), 'little')
    dump = get_dump(final, 0, len(memory), 4)
    name = 'fault' if inject else 'normal'
    (folder / (name + '_ucsim.txt')).write_text(
        'Последняя остановка программы и полное состояние внешней памяти\n' +
        re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', final))
    return ticks, dptr, status, port, checksum, dump


class Bus:
    """8051 bus cycle with an ALE latch, address decoder and a memory device."""

    def __init__(self, memory, read_only, ram_fault):
        self.memory = bytearray(memory)
        self.read_only = read_only
        self.ram_fault = ram_fault
        self.transactions = []
        self.trace = [(0, 'ALE', 0), (0, 'RD_N', 1), (0, 'WR_N', 1),
                      (0, 'LED', 0)]

    def instruction(self, time, ticks, movx):
        for cycle in range(0, ticks, 12):
            offsets = (7,) if movx and cycle == 12 else (1, 7)
            for offset in offsets:
                rise = time + cycle + offset
                self.trace.extend([(rise, 'ALE', 1), (rise + 2, 'ALE', 0)])

    def transfer(self, time, dptr, write, value):
        # P0 drives DPL while ALE is high, DD2 keeps it at the falling edge.
        p0, p2 = dptr & 255, dptr >> 8
        latched = p0
        address = (p2 << 8) | latched
        assert address < len(self.memory), 'DD4 deasserted /CE'
        strobe = 'WR_N' if write else 'RD_N'
        self.trace.extend([(time + 12, strobe, 0), (time + 18, strobe, 1)])
        if write:
            assert not self.read_only
            p0 = value
            self.memory[address] = p0
        else:
            # Fault deliberately changes the addressed RAM cell before reading.
            if self.ram_fault == address:
                self.memory[address] ^= 1
                self.ram_fault = None
            p0 = self.memory[address]
        self.transactions.append((time + 18, 'W' if write else 'R', address, p0))
        return p0


def simulate(program, labels, clocks, bus):
    # Only instructions used by the two supplied binaries are implemented.
    pc = time = dptr = a = carry = status = 0
    regs = [0] * 8
    port = 255

    def next_byte():
        nonlocal pc
        value = program[pc]
        pc += 1
        return value

    def jump(condition=True):
        nonlocal pc
        relative = next_byte()
        if condition:
            pc += relative if relative < 128 else relative - 256

    for _ in range(30_000):
        if pc == labels['halt']:
            return time, dptr, status, port, int.from_bytes(bytes(regs[2:5]), 'little')
        ticks = clocks[pc]
        op = next_byte()
        bus.instruction(time, ticks, op in (0xE0, 0xF0))
        if op in (0xC2, 0xD2):
            assert next_byte() == 0x90
            port = (port | 1) if op == 0xD2 else (port & 254)
            bus.trace.append((time + ticks, 'LED', int(not (port & 1))))
        elif op == 0x75:
            assert next_byte() == 0x30
            status = next_byte()
        elif op == 0x90:
            dptr = (next_byte() << 8) | next_byte()
        elif 0x78 <= op <= 0x7F:
            regs[op - 0x78] = next_byte()
        elif op == 0x74:
            a = next_byte()
        elif op == 0xE4:
            a = 0
        elif op in (0xE0, 0xF0):
            data = bus.transfer(time, dptr, op == 0xF0, a)
            if op == 0xE0:
                a = data
        elif op == 0x64:
            a ^= next_byte()
        elif 0x68 <= op <= 0x6F:
            a ^= regs[op - 0x68]
        elif op == 0x70:
            jump(a != 0)
        elif op == 0xA3:
            dptr = (dptr + 1) & 65535
        elif 0xD8 <= op <= 0xDF:
            reg = op - 0xD8
            regs[reg] = (regs[reg] - 1) & 255
            jump(regs[reg] != 0)
        elif op == 0x80:
            jump()
        elif 0x28 <= op <= 0x2F or 0x38 <= op <= 0x3F:
            total = a + regs[op & 7] + (carry if op >= 0x38 else 0)
            a, carry = total & 255, total >> 8
        elif 0xF8 <= op <= 0xFF:
            regs[op - 0xF8] = a
        elif op == 0x93:
            a = program[dptr + a]
        else:
            raise ValueError(f'Unsupported opcode {op:02x}')
        time += ticks
    raise RuntimeError('Program did not halt')


def vcd(folder, name, trace):
    signals = {'ALE': 'a', 'RD_N': 'r', 'WR_N': 'w', 'LED': 'l'}
    lines = ['$timescale 1 ps $end', '$scope module test_8051 $end']
    lines += [f'$var wire 1 {code} {signal} $end' for signal, code in signals.items()]
    lines += ['$upscope $end', '$enddefinitions $end', '#0']
    prev_time = 0
    for tick, signal, level in sorted(trace, key=lambda entry: entry[0]):
        if tick > 300:
            break
        time = round(tick * 1_000_000 / 12)
        if time != prev_time:
            lines.append(f'#{time}')
            prev_time = time
        lines.append(f'{level}{signals[signal]}')
    lines.append('#25000000')
    (folder / (name + '.vcd')).write_text('\n'.join(lines) + '\n')


def scenario(variant, kind, size, start, count, pattern=None):
    folder = OUT / f'variant_{variant:02}'
    if kind == 'ram':
        original = bytes([pattern ^ 255]) * (size * 1024)
        expected = None
        params = {'START_ADDR': start, 'PATTERN': pattern}
    else:
        original = bytes(((a * 73) ^ (a >> 5) ^ 0xA7) & 255 for a in range(size * 1024))
        expected = sum(original[start:start + count])
        params = {'START_ADDR': start, 'TAIL': count % 256, 'BLOCKS': (count + 255) // 256,
                  'SUM_LO': expected & 255, 'SUM_MID': (expected >> 8) & 255,
                  'SUM_HI': expected >> 16}
    assert start + count <= len(original)
    program, labels, clocks = make_firmware(folder, kind, params)
    if kind == 'rom':
        (folder / 'external_rom.bin').write_bytes(original)
    result = {'variant': variant, 'kind': kind, 'size': size, 'start': start,
              'end': start + count - 1, 'count': count, 'pattern': pattern,
              'expected': expected, 'runs': {}}
    for inject in (False, True):
        name = 'fault' if inject else 'normal'
        memory = bytearray(original)
        if kind == 'rom' and inject:
            memory[start] ^= 1
        bus = Bus(memory, kind == 'rom', start if kind == 'ram' and inject else None)
        model = simulate(program, labels, clocks, bus)
        ref = run_ucsim(folder, kind, labels, memory, start, inject, pattern)
        assert model[:4] == ref[:4] and bytes(bus.memory) == ref[5], (variant, model, ref[:5])
        ticks, dptr, status, port, checksum = model
        assert status == (2 if inject else 1) and (port & 1) == int(not inject)
        read = [(addr, data) for _, op, addr, data in bus.transactions if op == 'R']
        write = [(addr, data) for _, op, addr, data in bus.transactions if op == 'W']
        addresses = range(start, start + (1 if inject and kind == 'ram' else count))
        assert [addr for addr, _ in read] == list(addresses)
        if kind == 'ram':
            assert write == [(addr, pattern) for addr in addresses]
            assert [value for _, value in read] == ([pattern ^ 1] if inject else [pattern] * count)
            assert dptr == (start if inject else start + count)
            assert bus.memory[:start] == original[:start]
            assert bus.memory[start + count:] == original[start + count:]
        else:
            assert not write and checksum == ref[4] == sum(memory[start:start + count])
            assert (checksum == expected) == (not inject)
        result['runs'][name] = {'status': status, 'led': int(not (port & 1)),
                                'writes': len(write), 'reads': len(read), 'ticks': ticks,
                                'dptr': dptr, 'first': read[0][1], 'last': read[-1][1],
                                'checksum': checksum if kind == 'rom' else None}
        vcd(folder, name, bus.trace)
        if not inject:
            (folder / 'normal_trace.json').write_text(json.dumps(
                [item for item in sorted(bus.trace) if item[0] <= 240]))
        with (folder / (name + '_bus.csv')).open('w', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(['clock_tick', 'operation', 'address_hex', 'data_hex'])
            writer.writerows((tick, op, f'{addr:04X}', f'{value:02X}')
                             for tick, op, addr, value in bus.transactions)
    return result


def main():
    OUT.mkdir(exist_ok=True)
    results = []
    for variant, (size, pattern, start) in enumerate(RAM, 1):
        results.append(scenario(variant, 'ram', size, start, 1024, pattern))
    for variant, (size, count, start) in enumerate(ROM, 7):
        results.append(scenario(variant, 'rom', size, start, count))
    results.append(scenario(90, 'rom', 32, 2000, 500))
    (OUT / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
    print('26 successful simulations in uCsim and in the 8051 digital bus model.')


if __name__ == '__main__':
    main()
