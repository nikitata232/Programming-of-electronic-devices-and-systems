; Проверка 1 Кбайт внешнего ОЗУ 8051. Параметры задаёт params.inc.
.module ram_test
.include "params.inc"
.area PROGRAM (ABS,CODE)
.org 0x0000
    setb 0x90              ; P1.0 = 1, светодиод HL1 погашен
    mov  0x30,#0           ; состояние: 0 — тест, 1 — успех, 2 — ошибка
    mov  dptr,#START_ADDR  ; начальный адрес внешнего ОЗУ
    mov  r7,#4            ; четыре блока по 256 байт
    mov  r6,#0            ; DJNZ начинает отсчёт с 256 при R6 = 0
loop:
    mov  a,#PATTERN       ; тестовый байт XX
    movx @dptr,a          ; записать байт по внешней шине
readback:
    movx a,@dptr          ; считать байт из той же ячейки
    xrl  a,#PATTERN       ; результат 0 при совпадении
    jnz  fail             ; при ошибке DPTR сохраняет адрес ячейки
    inc  dptr             ; перейти к следующему адресу
    djnz r6,loop          ; завершить текущий блок
    djnz r7,loop          ; перейти к следующему блоку
    mov  0x30,#1          ; весь диапазон проверен
    sjmp halt
fail:
    clr  0x90             ; P1.0 = 0, светодиод HL1 включён
    mov  0x30,#2          ; зафиксировать ошибку
halt:
    sjmp halt             ; удерживать состояние индикатора
